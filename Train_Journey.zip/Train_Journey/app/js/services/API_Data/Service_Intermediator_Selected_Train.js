/**
 * Created by komal.chaudhary on 2/24/2016.
 */

//used for holding selected train Info

angular.module("myApp").factory('Service_Intermediator_Selected_Train', function () {
    return { Train : [] };
});